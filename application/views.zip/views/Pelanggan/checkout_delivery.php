<!-- Title Page -->
<section class="bg-title-page flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(<?= base_url('asset/pato-master/') ?>images/bg-title-page-02.jpg);">
    <h2 class="tit6 t-center">
        Checkout
    </h2>
</section>


<!-- Reservation -->
<section class="section-reservation bg1-pattern p-t-100 p-b-113">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="t-center">
                    <span class="tit2 t-center">
                        SISI JALAN KOPI
                    </span>

                    <h3 class="tit3 t-center m-b-35 m-t-2">
                        Checkout Kirim
                    </h3>
                </div>
            </div>
            <div class="col-lg-8 p-b-30">
                <form action="<?= base_url('pelanggan/chome/checkout_deliv') ?>" method="POST" class="wrap-form-reservation size22 m-l-r-auto">
                    <input type="hidden" name="total" class="pembayaran">
                    <?php $id_transaksi = date('Ymd') . strtoupper(random_string('alnum', 8));
                    ?>
                    <input type="hidden" name="id_transaksi" value="<?= $id_transaksi ?>">
                    <?php
                    $i = 1;
                    foreach ($this->cart->contents() as $items) {
                        echo form_hidden('qty' . $i++, $items['qty']);
                    }
                    ?>
                    <input type="hidden" name="ongkir">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- Name -->
                            <span class="txt9">
                                Atas Nama
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <input class="bo-rad-10 sizefull txt10 p-l-20" value="<?= $pelanggan->nama_pelanggan ?>" type="text" placeholder="Name" readonly>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <!-- Name -->
                            <span class="txt9">
                                No Telepon
                            </span>

                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <input class="bo-rad-10 sizefull txt10 p-l-20" value="<?= $pelanggan->no_hp ?>" type="text" placeholder="Name" readonly>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <!-- Name -->
                            <span class="txt9">
                                Pilih Metode Pembayaran
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <select id="pembayaran" name="pembayaran" class="bo-rad-10 sizefull txt10 p-l-20">
                                    <option value="">---Metode Pembayaran---</option>
                                    <option data-pembayaran="<?= $this->cart->total() - (0.05 * $this->cart->total()) ?>" data-total="Rp. <?= $this->cart->format_number($this->cart->total() - (0.05 * $this->cart->total())); ?>" data-diskon="5%" value="2">Transfer Bank Cimb Niaga</option>
                                    <option data-pembayaran="<?= $this->cart->total() ?>" data-total="Rp. <?= $this->cart->format_number($this->cart->total()); ?>" data-diskon="-" value="3">Transfer Bank BRI</option>
                                </select>
                                <?= form_error('pembayaran', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <!-- Name -->
                            <span class="txt9">
                                Kota/Kabupaten
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <select name="kota" class="bo-rad-10 sizefull txt10 p-l-20">

                                </select>
                                <?= form_error('kota', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <!-- Name -->
                            <span class="txt9">
                                Alamat
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <input class="bo-rad-10 sizefull txt10 p-l-20" name="alamat" type="text" placeholder="Alamat">
                                <?= form_error('alamat', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <!-- Name -->
                            <span class="txt9">
                                RT
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <input class="bo-rad-10 sizefull txt10 p-l-20" name="rt" type="text" placeholder="RT">
                                <?= form_error('rt', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                        </div>

                        <div class="col-md-6">
                            <!-- Name -->
                            <span class="txt9">
                                RW
                            </span>

                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <input class="bo-rad-10 sizefull txt10 p-l-20" name="rw" type="text" placeholder="RW">
                                <?= form_error('rw', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <!-- Name -->
                            <span class="txt9">
                                Expedisi
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <select name="expedisi" class="bo-rad-10 sizefull txt10 p-l-20">

                                </select>
                                <?= form_error('expedisi', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <!-- Name -->
                            <span class="txt9">
                                Paket
                            </span>
                            <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                <select name="paket" class="bo-rad-10 sizefull txt10 p-l-20">

                                </select>
                                <?= form_error('paket', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="wrap-btn-booking flex-c-m m-t-6">
                        <!-- Button3 -->
                        <button type="submit" class="btn3 flex-c-m size13 txt11 trans-0-4">
                            Checkout
                        </button>
                    </div>

                </form>
            </div>

            <div class="col-lg-4">
                <p>Dapatkan Diskon hingga 5% jika metode pembayaran kamu menggunakan transfer via bank <strong>Cimb Niaga</strong></p>
                <table class="table table-striped">
                    <tr>
                        <th>Keranjang</th>
                        <th>&nbsp;</th>
                    </tr>
                    <tr>
                        <td>Subtotal</td>
                        <td>
                            <h5>Rp. <?php echo $this->cart->format_number($this->cart->total()); ?></h5>
                        </td>
                    </tr>
                    <tr>
                        <td>Diskon</td>
                        <td class="diskon"></td>
                    </tr>
                    <tr>
                        <td>Subtotal Diskon</td>
                        <td>
                            <h5 class="total"></h5>
                        </td>
                    </tr>
                    <tr>
                        <td>Ongkir</td>
                        <td id="ongkir"></td>

                    </tr>

                </table>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->





<!-- Back to top -->
<div class="btn-back-to-top bg0-hov" id="myBtn">
    <span class="symbol-btn-back-to-top">
        <i class="fa fa-angle-double-up" aria-hidden="true"></i>
    </span>
</div>

<!-- Container Selection1 -->
<div id="dropDownSelect1"></div>

<!-- Modal Video 01-->
<div class="modal fade" id="modal-video-01" tabindex="-1" role="dialog" aria-hidden="true">

    <div class="modal-dialog" role="document" data-dismiss="modal">
        <div class="close-mo-video-01 trans-0-4" data-dismiss="modal" aria-label="Close">&times;</div>

        <div class="wrap-video-mo-01">
            <div class="w-full wrap-pic-w op-0-0"><img src="images/icons/video-16-9.jpg" alt="IMG"></div>
            <div class="video-mo-01">
                <iframe src="https://www.youtube.com/embed/5k1hSu2gdKE?rel=0&amp;showinfo=0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>



<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/bootstrap/js/popper.js"></script>
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/slick/slick.min.js"></script>
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>js/slick-custom.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/parallax100/parallax100.js"></script>
<script type="text/javascript">
    $('.parallax100').parallax100();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="<?= base_url('asset/pato-master/') ?>vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('asset/pato-master/') ?>js/main.js"></script>
<script>
    window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function() {
            $(this).remove();
        });
    }, 3000)
</script>
<script>
    console.log = function() {}
    $("#pembayaran").on('change', function() {
        $(".diskon").html($(this).find(':selected').attr('data-diskon'));
        $(".diskon").val($(this).find(':selected').attr('data-diskon'));


        $(".total").html($(this).find(':selected').attr('data-total'));
        $(".total").val($(this).find(':selected').attr('data-total'));


        $(".pembayaran").html($(this).find(':selected').attr('data-pembayaran'));
        $(".pembayaran").val($(this).find(':selected').attr('data-pembayaran'));
    });
</script>

<script>
    $(document).ready(function() {

        $.ajax({
            type: "POST",
            url: "http://localhost/sisi-jalan/pelanggan/cOngkir/kota",
            success: function(hasil_kota) {
                //console.log(hasil_kota);
                $("select[name=kota]").html(hasil_kota);
            }
        });

        $("select[name=kota]").on("change", function() {
            $.ajax({
                type: "POST",
                url: "http://localhost/sisi-jalan/pelanggan/cOngkir/expedisi",
                success: function(hasil_expedisi) {
                    $("select[name=expedisi]").html(hasil_expedisi);
                }
            });
        });

        $("select[name=expedisi]").on("change", function() {
            //mendapatkan expedisi terpilih
            var expedisi_terpilih = $("select[name=expedisi]").val()

            //mendapatkan id kota tujuan terpilih
            var id_kota_tujuan_terpilih = $("option:selected", "select[name=kota]").attr('id_kota');
            //mengambil data ongkos kirim
            var total_berat = 500;
            //alert(total_berat);
            $.ajax({
                type: "POST",
                url: "http://localhost/sisi-jalan/pelanggan/cOngkir/paket",
                data: 'expedisi=' + expedisi_terpilih + '&id_kota=' + id_kota_tujuan_terpilih + '&berat=' + total_berat,
                success: function(hasil_paket) {
                    $("select[name=paket]").html(hasil_paket);
                }
            });
        });


        $("select[name=paket]").on("change", function() {
            //menampilkan ongkir
            var dataongkir = $("option:selected", this).attr('ongkir');
            var reverse = dataongkir.toString().split('').reverse().join(''),
                ribuan_ongkir = reverse.match(/\d{1,3}/g);
            ribuan_ongkir = ribuan_ongkir.join(',').split('').reverse().join('');
            //alert(dataongkir);
            $("#ongkir").html("Rp. " + ribuan_ongkir)
            //menghitung total bayar
            var ongkir = $("option:selected", this).attr('ongkir');
            var total_bayar = parseInt(ongkir) + parseInt(<?= $this->cart->total() ?>);

            var reverse2 = total_bayar.toString().split('').reverse().join(''),
                ribuan_total = reverse2.match(/\d{1,3}/g);
            ribuan_total = ribuan_total.join(',').split('').reverse().join('');
            $("#total_bayar").html("Rp. " + ribuan_total);
            $(".total_bayar").html("Rp. " + ribuan_total);

            //estimasi dan ongkir
            var estimasi = $("option:selected", this).attr('estimasi');
            $("input[name=estimasi]").val(estimasi);
            $("input[name=ongkir]").val(dataongkir);
            $("input[name=total_bayar]").val(total_bayar);
        });


    });
</script>